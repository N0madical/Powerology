function sus() {
    console.debug("Color Changer")
} 


function sus2() {
    console.debug("Open Class")
} 
